<?php
$buy = $_GET['buy'];
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=./beli/<?php echo $buy;?>.php" />
</head>
<body>
</body>
</html>