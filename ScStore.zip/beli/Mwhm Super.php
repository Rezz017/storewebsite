<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Description" content="SITE REZZ GANZ">
	<meta property="og:type" content="website">
	<meta property="og:title" content="SITE REZZ GANZ">
	<meta property="og:description" content="By Ryzn Ganz">
	<meta property="og:image" content="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="icon" type="image/png" href="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="../css/style.css">
<title>REZZ STORE</title>
</head>


<body>

	<div class="box">


<div class="nav">
REZZ STORE
</div>
<br><br>
<div style="background:#1ed0ff; margin-top: 5%; color: #fff;">
<center>
	<i class="fa fa-html5 fa-1g" aria-hidden="true" style="margin-right: 10px;"></i>
		<span class="fa-stack fa-lg">
		<i class="fa fa-square fa-stack-2x" style="color: #000;"></i>
		<i class="fa fa-code fa-stack-1x fa-inverse"></i>
		</span>
	<i class="fa fa-css3 fa-1g" aria-hidden="true" style="margin-left: 10px;"></i>
</center>
</div>

<div class="garis-home"></div>
<div class="solusi"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>  Shoping Cart</div>
<center>
<div class="cart">
Item: <b> Mwhm Super</b><br><br>
Jumlah: Rp 150.000-,<br><br>

<script type="text/javascript">
    function copy_text1() {
        document.getElementById("dompet").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>
<script type="text/javascript">
    function copy_text2() {
        document.getElementById("pulsa").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>
	Silahkan bayar lewat:<br>
<b>Dana/Ovo/Gopay</b><br>
	No: <input type="text" value="KE WA AJA" id="dompet" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px">
	<button type="button" onclick="copy_text1()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
	</input>
	<br><br>
	
<b>Pulsa </b><br>
	No: <input type="text" value="081313726400" id="pulsa" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px">
	<button type="button" onclick="copy_text2()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
	</input>

<br>
<br>
<form action="selesai/web.php">
	<div class="form">
		</select>
		<br>
		<select name="bayar" required> 
			<option selected="selected" disabled="disabled" value="">pilih pembayaran</option> 			
			<option>Dana/Ovo/Gopay</option>
			<option>Pulsa</option> 
		</select>
	</div>
	<center>
	<button type="submit" class="beli2">
	Lanjut <i class="fa fa-arrow-circle-right fa-1g" aria-hidden="true"></i>
	</button>
	</center>
</form>
<br>
<b style="color: red;">*</b>Setelah membayar harap konfirmasi lewat Whatsapp dan mengirimkan bukti.
</div>
</center>

	</div>

<footer style="color: white;">
	<h3> Tentang Kami</h3>
<li>Created by : <a href="https://wa,me6281313726400" style="text-decoration: none;"><i>Rezz19</i></a></li>
<li>Email : <i style="color: white;">galaxypedia@protonmail.com</i></li>
<li>Subscribe :<a href="https://www.youtube.com/-" style="text-decoration: none;"> <i>Youtube Channel</i></a></li>
<li>Follow :<a href="https://instagram.com/-" style="text-decoration: none;"> <i>Instagram</i></a></li>
<br>

<div class="barcode">
REZZ X HOSTING
</div>
</footer>



</body>
</html>
