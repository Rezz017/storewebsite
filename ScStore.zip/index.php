 <!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Description" content="SITE REZZ GANZ">
	<meta property="og:type" content="website">
	<meta property="og:title" content="SITE REZZ GANZ">
	<meta property="og:description" content="Ready Kebutuhan Hosting and jasa sewa bot
	">
	<meta property="og:image" content="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="icon" type="image/png" href="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/slider.css">
<title>REZZ STORE</title>

	<script src="js/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="css/sweetalert2.min.css">


</head>


<body>


	
<script>
window.onload = function() {
var h1 = document.getElementsByTagName("h2")[0],
text = h1.innerText || h1.textContent,
split = [], i, lit = 0, timer = null;
for(i = 0; i < text.length; ++i) {
split.push("<span>" + text[i] + "</span>");
}
h1.innerHTML = split.join("");
split = h1.childNodes;

var flicker = function() {
lit += 0.01;
if(lit >= 1) {
clearInterval(timer);
}
for(i = 0; i < split.length; ++i) {
if(Math.random() < lit) {
split[i].className = "neon";
} else {
split[i].className = "";
}
}
}
setInterval(flicker, 100);
}
</script>

 <center>
<div class="box">
                <script type="text/javascript">
                    Swal.fire({
                        title: 'HAI SELAMAT DATANG DI WEB REZZ STORE',
                        text: 'SELAMAT DATANG DI REZZ STORE',
                        imageUrl: 'https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg',
                        imageWidth: 150,
                        imageHeight: 150,
                        imageAlt: 'Custom image',
                    })
                </script>

	
	
<h2 class="nav2">
WELLCOME
</h2>
<div class="nav">
REZZ STORE
</div>
<br><br>
<div style="background:#1ed0ff; margin-top: 5%; color: #fff;">
<center>
	<i class="fa fa-html5 fa-1g" aria-hidden="true" style="margin-right: 10px;"></i>
		<span class="fa-stack fa-lg">
		<i class="fa fa-square fa-stack-2x" style="color: #000;"></i>
		<i class="fa fa-code fa-stack-1x fa-inverse"></i>
		</span>
	<i class="fa fa-css3 fa-1g" aria-hidden="true" style="margin-left: 10px;"></i>
</center>
</div>

<div class="garis-home"></div>

	<div class="slider">
		<figure>
			<div class="slide">
				<img src="https://i.ibb.co/NyWyTRZ/20210316-162813.jpg">
			</div>
 
			<div class="slide">
				<img src="https://i.ibb.co/NyWyTRZ/20210316-162813.jpg">
			</div>
 
			<div class="slide">
				<img src="https://i.ibb.co/NyWyTRZ/20210316-162813.jpg">
			</div>
 
			<div class="slide">
				<img src="https://i.ibb.co/NyWyTRZ/20210316-162813.jpg">
			</div>
			
			<div class="slide">
				<img src="https://i.ibb.co/NyWyTRZ/20210316-162813.jpg">
			</div>
 
		</figure>
	</div>


<div class="tab">

		<button type="submit" class="log-cpanel" onclick="location.href='https://cybernet.darkknighthostlive.com:2083/';" style="border: none;"><i class="fa fa-sign-in" aria-hidden="true"></i> Log Cpanel</button>
		<button type="submit" class="buy" onclick="location.href='#beli';" style="border: none;"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Beli</button>
</div>

<div class="tab2">
	<button onclick="location.href='#cpanel';">
	Cpanel <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#script';">
	Script <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#web';">
	Web Phising <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#domain';">
	Domain <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<!-- <button onclick="location.href='#testi';">
	Testimoni <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button> -->
	<button onclick="location.href='#kontak';">
	Kontak <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#beli';">
	Beli <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#server';">
	Server <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
</div>



    <iframe scrolling='no' allow='autoplay' src='Lagu/musik.mp3' width='0' height='0' frameborder='no'></iframe>

<!-- popup -->
		<div id="peraturan">
           <div class="window">
					<div class="popup">Peraturan</div>
				<hr>
				<br>
				<br>
				<div class="harga3">
					
					- Dilarang package default<br>
					- Dilarang menggunakan sender/mailer<br>
					- Dilarang membuat web Checker<br>
					<br><br>
					<!-- CARA MENGGUNAKAN DOMAIN : 
					<br><br>
					<i class="fa fa-check-circle" aria-hidden="true" style="color: #09b051;"></i> namaweblu.domain.com  ( Benar ) 
					<br>
					<i class="fa fa-times-circle" aria-hidden="true" style="color: #ff0000;"></i> domain.com ( Salah )
					<br><br> -->
					IKUTI PERATURAN YANG TELAH DI BUAT<br>
					MELANGGAR? TERMIN USER TANPA KATA REFF !
				</div>
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
		<div id="coming-soon">
           <div class="window">
					<div class="popup">Coming Soon</div>
				<hr>
				<br>
				<br>
					SCRIPT INI BELUM SELESAI, TUNGGU YAAAA...
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
    <div id="cpanel">
           <div class="window">
					<div class="popup">Cpanel</div>
				<hr>
				<div class="harga2">
				
				<br>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i> Cpanel   = Rp 10k</li>
				</div>
			    
				
				<button class="peraturan" type="button" onclick="location.href='#peraturan';">Peraturan <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#fff;"></i></button>
				
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="script">
           <div class="window">
					<div class="popup">SCRIPT PHISING</div>
				<hr>
				<div class="harga">
				<br>
				<li>Script Codashop   = Rp 10k</li>
				<center>
				<div class="demo" onclick="location.href='https://i.ibb.co/h8ZxgHw/20210315-215207.jpg';">
				<i class="fa fa-link" aria-hidden="true" style="color: #fff;"></i> Demo Script
				</div>
				</center>
				<li>Script Lain Nya   = Rp 10k</li>
				<center>
				<div class="demo" onclick="location.href='#coming-soon';">
				<i class="fa fa-link" aria-hidden="true" style="color: #fff;"></i> Demo Script
				</div>
				</center>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="web">
           <div class="window">
					<div class="popup">WEB PHISING</div>
				<hr>
				<div class="harga2">
				<br>
				<!-- <center><b> WEB CODASHOP </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>web p Codashop   = Rp 15k (1x garansi)</li>
				<br> -->
				<center><b> WEB ALL TAMPILAN </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 0x garansi   = Rp 10k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 1x garansi   = Rp 15k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 2x garansi   = Rp 20k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 3x garansi   = Rp 25k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 4x garansi   = Rp 30k</li>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="domain">
           <div class="window">
					<div class="popup">DOMAIN</div>
				<hr>
				<div class="harga">
				<br>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>1 Domain  cloudflare   = Rp 1.000</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>10 Domain cloudflare  = Rp 10.000</li>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="testi">
           <div class="window">
			<!-- <div class="scroll"> -->
					<div class="popup">TESTIMONI</div>
				<hr>
				<!-- <img src="" style="float: left; margin-left: 5%;" onclick="location.href='';"></img>

				<img src="" style="float: right; margin-right: 5%;" onclick="location.href='';"></img>
				
				<img src="" style="float: left; margin-left: 5%;" onclick="location.href='';"></img>

				<img src="" style="float: right; margin-right: 5%;" onclick="location.href='';"></img>
				
				<img src="" style="float: left; margin-left: 5%;" onclick="location.href='';"></img>

				<img src="" style="float: right; margin-right: 5%;" onclick="location.href='';"></img>
				
				<img src="" style="float: left; margin-left: 5%;" onclick="location.href='';"></img>

				<img src="" style="float: right; margin-right: 5%;" onclick="location.href='';"></img> -->
			   
			   <br>
			   
			   <div class="testi-bottom">
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>
			   </div>
			   </div>

			</div>
			</div>
       </div>
	   
	   <div id="kontak">
           <div class="window">
					<div class="popup">KONTAK</div>
				<hr>
				<center>
				<button type="submit" class="whatsapp" onclick="location.href='https://wa.me/6281313726400';" style="border: none;">
				<i class="fa fa-whatsapp fa-1g" aria-hidden="true" style="color: #fff;"></i> Whatsapp
				
				</button>
				<button type="submit" class="instagram" onclick="location.href='https://instagram.com/ini_rezz19';" style="border: none;"> 
				<i class="fa fa-facebook fa-1g" aria-hidden="true" style="color: #fff;"></i> Facebook
				</button>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="beli">
           <div class="window">
					<div class="popup">BELI</div>
				<hr>
				<center>
				<form action="lane.php" method="get">
				<select class="beli" name="buy" required> 
					<option selected="selected" disabled="disabled" value="">pilih</option> 
					<option>Web phising 0x</option> 
					<option>Web phising 1x</option> 
					<option>Web phising 2x</option> 
					<option>Web phising 3x</option> 
					<option>Whm Mini</option>
					<option>Whm Medium</option> 
					<option>Whm Extra</option> 
					<option>Whm Super</option>
					<option>Mwhm Mini</option>
					<option>Mwhm Medium</option>
					<option>Mwhm Extra</option>
					<option>Mwhm Super</option>
					<option>AdminHost</option>
					<option>CeoHost</option>
					<option>Wk.Founder</option>
					<option>Domain cloudflare</option>
				</select>
				<button type="submit" class="beli2">
				BELI <i class="fa fa-arrow-circle-right fa-1g" aria-hidden="true"></i>
				</button>
				</form>
				</center>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="server">
           <div class="window">
				<div class="popup">Server</div>
				<hr>
				<br>
				<center>
				<div class="REZZMEDIAHOST" onclick="location.href='#';">
					<!-- <img src="https://i.ibb.co/NnZYWcz/540718bc7c9d.jpg"/> -->
				</div>
				<br>
			<div style="text-align: left; margin-left: 25px;">
				<b>Name server 1</b>
				<br>
				<input type="text" value="ns1.darkknighthostlive.com" id="ns1" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text1()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
				<br><br>
				<b>Name server 2</b>
				<br>
				<input type="text" value="http://n2.darkknighthostlive.com" id="ns2" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text2()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
				<br><br>
				<b>IP</b>
				<br>
				<input type="text" value="kepo yaa :v" id="ip" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text3()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
			</div>
				</center>
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
<script type="text/javascript">
    function copy_text1() {
        document.getElementById("ns1").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<script type="text/javascript">
    function copy_text2() {
        document.getElementById("ns2").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<script type="text/javascript">
    function copy_text3() {
        document.getElementById("ip").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<!-- popup -->

</div>
</center>

<footer style="color: white;">
	<h3> Info Creator</h3>
<li>Created by : <a href="https://wa.me//6281313726400" style="text-decoration: none;"><i>REZZ STORE</i></a></li>
<li>Email : <i style="color: white;">galaxypedia@protonmail.com</i></li>
<li>Subscribe :<a href="https://www.youtube.com/channel/-" style="text-decoration: none;"> <i>Youtube Channel</i></a></li>
<li>Follow :<a href="https://instagram.com/-" style="text-decoration: none;"> <i>Instagram</i></a></li>
<br>

<div class="barcode">
REZZ19 STORE
</div>
</footer>


</body>
</html>
